package com.dtsfreefireth;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class FloatingWindow extends Service {
    
    private WindowManager windowManager;
    private View floatingView;
    private TextView infoText;
    private boolean isVisible = true;
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onCreate() {
        super.onCreate();
        createFloatingWindow();
    }
    
    private void createFloatingWindow() {
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_window, null);
        
        int layoutType;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutType = WindowManager.LayoutParams.TYPE_PHONE;
        }
        
        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        );
        
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 50;
        params.y = 200;
        
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        windowManager.addView(floatingView, params);
        
        // Initialize views
        infoText = floatingView.findViewById(R.id.infoText);
        ImageView closeBtn = floatingView.findViewById(R.id.closeBtn);
        ImageView hideBtn = floatingView.findViewById(R.id.hideBtn);
        
        closeBtn.setOnClickListener(v -> stopSelf());
        hideBtn.setOnClickListener(v -> toggleVisibility());
        
        // Make draggable
        floatingView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, params);
                        return true;
                }
                return false;
            }
        });
        
        // Update info every second
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                updateMonitorInfo();
                if (floatingView != null) {
                    new Handler().postDelayed(this, 1000);
                }
            }
        }, 1000);
    }
    
    private void updateMonitorInfo() {
        String info = "🎯 FREE FIRE MONITOR\n";
        info += "Status: " + NativeCheat.getGameStatus() + "\n";
        info += "Enemies: " + NativeCheat.getEnemyCount() + "\n";
        info += "Health: " + NativeCheat.getPlayerHealth() + "%\n";
        info += "Active: " + NativeCheat.getActiveCheats() + "\n";
        info += "FPS: " + NativeCheat.getGameFPS() + "\n";
        
        if (infoText != null) {
            infoText.setText(info);
        }
    }
    
    private void toggleVisibility() {
        if (isVisible) {
            floatingView.setVisibility(View.GONE);
            isVisible = false;
        } else {
            floatingView.setVisibility(View.VISIBLE);
            isVisible = true;
        }
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (windowManager != null && floatingView != null) {
            windowManager.removeView(floatingView);
        }
    }
}