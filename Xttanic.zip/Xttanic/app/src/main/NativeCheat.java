package com.dtsfreefireth;

public class NativeCheat {
    
    // Native methods
    public static native boolean isGameRunning();
    public static native void toggleFeature(String feature, boolean enable);
    public static native void scanEnemies();
    public static native void applyCheats();
    public static native String getGameStatus();
    public static native int getEnemyCount();
    public static native int getPlayerHealth();
    public static native String getActiveCheats();
    public static native int getGameFPS();
    
    // Cheat features
    public static final String AIM_HEAD = "aim_head";
    public static final String AIM_LOCK = "aim_lock";
    public static final String AIM_BODY_HEADSHOT = "aim_body_headshot";
    public static final String AUTO_LOCK = "auto_lock";
    public static final String AIM_50 = "aim_50";
    public static final String BOOST_GAME = "boost_game";
    
    static {
        System.loadLibrary("cheat");
        System.loadLibrary("memory");
    }
}