package com.dtsfreefireth;

import android.app.*;
import android.os.*;
import android.webkit.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;

public class MainActivity extends Activity {
    
    private WebView webView;
    private ProgressBar loadingBar;
    private boolean isServiceRunning = false;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Request overlay permission
        requestOverlayPermission();
        
        // Setup WebView
        webView = findViewById(R.id.webview);
        loadingBar = findViewById(R.id.loadingBar);
        
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        
        // Enable hardware acceleration
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        
        // Add JavaScript interface
        webView.addJavascriptInterface(new WebAppInterface(this), "Android");
        
        // Load HTML
        webView.loadUrl("file:///android_res/raw/index.html");
        
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                loadingBar.setVisibility(View.GONE);
                webView.setVisibility(View.VISIBLE);
            }
            
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }
        });
        
        // Start background service
        startService(new Intent(this, CheatService.class));
        isServiceRunning = true;
    }
    
    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                startActivityForResult(intent, 0);
            }
        }
    }
    
    public class WebAppInterface {
        Context mContext;
        
        WebAppInterface(Context c) {
            mContext = c;
        }
        
        @JavascriptInterface
        public void showToast(String message) {
            Toast.makeText(mContext, message, Toast.LENGTH_SHORT).show();
        }
        
        @JavascriptInterface
        public void toggleCheat(String cheatName, boolean enable) {
            NativeCheat.toggleFeature(cheatName, enable);
        }
        
        @JavascriptInterface
        public void startFloatingWindow() {
            startService(new Intent(mContext, FloatingWindow.class));
        }
        
        @JavascriptInterface
        public void stopFloatingWindow() {
            stopService(new Intent(mContext, FloatingWindow.class));
        }
        
        @JavascriptInterface
        public String getGameStatus() {
            return NativeCheat.getGameStatus();
        }
        
        @JavascriptInterface
        public int getPlayerCount() {
            return NativeCheat.getEnemyCount();
        }
    }
    
    @Override
    protected void onDestroy() {
        if (isServiceRunning) {
            stopService(new Intent(this, CheatService.class));
        }
        super.onDestroy();
    }
    
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
