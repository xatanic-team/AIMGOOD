// Main JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Hide loading screen after 2 seconds
    setTimeout(() => {
        document.getElementById('loading').style.opacity = '0';
        setTimeout(() => {
            document.getElementById('loading').style.display = 'none';
            document.querySelector('.container').style.opacity = '1';
        }, 500);
    }, 2000);
    
    // Initialize variables
    let activeCheats = new Set();
    let monitorActive = false;
    let gameConnected = false;
    
    // Setup event listeners
    setupEventListeners();
    
    // Start status updates
    updateStatusLoop();
});

function setupEventListeners() {
    // Cheat toggles
    document.querySelectorAll('.cheat-toggle').forEach(toggle => {
        toggle.addEventListener('change', function() {
            const cheatCard = this.closest('.cheat-card');
            const cheatName = cheatCard.dataset.cheat;
            const isEnabled = this.checked;
            
            if (isEnabled) {
                activeCheats.add(cheatName);
                cheatCard.style.borderColor = '#00ff88';
                Android.showToast(`✅ ${cheatName.toUpperCase()} ACTIVATED`);
            } else {
                activeCheats.delete(cheatName);
                cheatCard.style.borderColor = '';
                Android.showToast(`❌ ${cheatName.toUpperCase()} DEACTIVATED`);
            }
            
            // Call native method
            Android.toggleCheat(cheatName, isEnabled);
            updateActiveCount();
        });
    });
    
    // Control buttons
    document.getElementById('toggleMonitor').addEventListener('click', function() {
        monitorActive = !monitorActive;
        
        if (monitorActive) {
            Android.startFloatingWindow();
            Android.showToast('📊 Floating Monitor Started');
            this.innerHTML = '<span class="btn-icon">📊</span><span class="btn-text">HIDE MONITOR</span>';
        } else {
            Android.stopFloatingWindow();
            Android.showToast('📊 Floating Monitor Stopped');
            this.innerHTML = '<span class="btn-icon">📊</span><span class="btn-text">SHOW MONITOR</span>';
        }
    });
    
    document.getElementById('applyAll').addEventListener('click', function() {
        // Enable all cheats
        document.querySelectorAll('.cheat-toggle').forEach(toggle => {
            if (!toggle.checked) {
                toggle.checked = true;
                toggle.dispatchEvent(new Event('change'));
            }
        });
        Android.showToast('⚡ ALL CHEATS ACTIVATED');
    });
    
    document.getElementById('stopAll').addEventListener('click', function() {
        // Disable all cheats
        document.querySelectorAll('.cheat-toggle').forEach(toggle => {
            if (toggle.checked) {
                toggle.checked = false;
                toggle.dispatchEvent(new Event('change'));
            }
        });
        Android.showToast('⛔ ALL CHEATS DEACTIVATED');
    });
}

function updateStatusLoop() {
    // Update game status every 3 seconds
    setInterval(() => {
        const status = Android.getGameStatus();
        const enemyCount = Android.getPlayerCount();
        
        // Update UI
        document.getElementById('gameStatus').querySelector('.status-text').textContent = status;
        document.getElementById('enemyCount').textContent = enemyCount;
        document.getElementById('statusText').textContent = status;
        
        // Update status icon color
        const statusIcon = document.querySelector('.status-icon');
        if (status.includes('RUNNING')) {
            statusIcon.style.color = '#00ff88';
            gameConnected = true;
        } else {
            statusIcon.style.color = '#ff4444';
            gameConnected = false;
        }
        
        // Update active count
        updateActiveCount();
        
        // Update memory usage (simulated)
        const memory = Math.floor(Math.random() * 100) + 50;
        document.getElementById('memoryUsage').textContent = memory + ' MB';
        
    }, 3000);
}

function updateActiveCount() {
    document.getElementById('activeCount').textContent = activeCheats.size;
    
    // Update status badge
    const statusBadge = document.getElementById('gameStatus');
    if (activeCheats.size > 0) {
        statusBadge.style.background = 'rgba(0, 80, 0, 0.5)';
    } else {
        statusBadge.style.background = 'rgba(80, 0, 0, 0.5)';
    }
}

// Utility functions
function formatCheatName(name) {
    return name.split('_').map(word => 
        word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
}

// Simulate cheat effects (for demo)
function simulateCheatEffect(cheatName) {
    const effects = {
        'aim_head': { accuracy: 95, damage: 240 },
        'aim_lock': { stickiness: 100, reaction: 50 },
        'aim_body_headshot': { bypass: true, damage: 240 },
        'auto_lock': { detection: 360, priority: 'nearest' },
        'aim_50': { strength: 50, stealth: 'high' },
        'boost_game': { fps: 30, latency: -40 }
    };
    
    return effects[cheatName] || {};
}