# FREE FIRE CHEAT v14

## Features
- 🎯 AIM HEAD - Auto headshot
- 🔒 AIM LOCK - Permanent lock
- 💀 AIM BODY HEADSHOT - Body shot registers as headshot
- 🤖 AUTO LOCK - Automatic targeting
- 🎮 AIM 50% - Reduced aim for stealth
- 🚀 BOOST GAME - Performance optimization
- 📊 FLOATING MONITOR - Real-time stats

## Requirements
- Android 5.0+ (API 21)
- FreeFire game installed
- Overlay permission granted
- Storage permission

## Installation
1. Build APK using Android Studio
2. Install on Android device
3. Grant overlay permission when prompted
4. Open app and enable desired cheats
5. Start FreeFire game

## Warning
⚠️ FOR EDUCATIONAL PURPOSE ONLY  
⚠️ USE AT YOUR OWN RISK  
⚠️ MAY RESULT IN ACCOUNT BAN

## Build Instructions
```bash
./gradlew assembleDebug